 <div class="col-3">
     <label for="PROVINSI" class="form-label">Provinsi</label>
     <select class="form-select select-wilayah" id="PROVINSI" name="PROVINSI" style="width: 100%"></select>
 </div>
 <div class="col-3">
     <label for="KABUPATEN" class="form-label">Kabupaten</label>
     <select class="form-select select-wilayah" id="KABUPATEN" name="KABUPATEN" style="width: 100%"></select>
 </div>
 <div class="col-3">
     <label for="KECAMATAN" class="form-label">Kecamatan</label>
     <select class="form-select select-wilayah" id="KECAMATAN" name="KECAMATAN" style="width: 100%"></select>
 </div>
 <div class="col-3">
     <label for="kelurahan" class="form-label">Kelurahan</label>
     <select class="form-select select-wilayah" id="KELURAHAN" name="KELURAHAN" style="width: 100%"></select>
 </div>