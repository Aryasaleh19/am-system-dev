<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Maaf</strong> fitur orang tua belum tersedia
</div>