<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Maaf</strong> fitur berkas siswa belum tersedia
</div>