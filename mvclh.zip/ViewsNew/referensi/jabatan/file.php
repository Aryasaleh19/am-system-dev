<input type="hidden" name="id" id="id" value="<?= $id_jabatan ?>"> <!-- id jabatan dari modal -->
<div class="card text-white bg-warning">
    <div class="card-body">
        <h4 class="card-title text-white"><i class="fa fa-gears" aria-hidden="true"></i> Maintenance</h4>
        <p class="card-text">Fitur ini sedang dalam tahap pengembangan</p>
    </div>
</div>